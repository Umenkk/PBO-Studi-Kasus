import java.util.Scanner;

public class pembayaran extends byr implements bayar {


    @Override
    public void bayarr(int uang) {
        System.out.println("Uang pembayaran anda : " + uang);
        }

    public void setTotalll(int pilihan, int hari) {
        if(pilihan == 1){
            this.total= hari*20000;
        }
        else if (pilihan == 2) {
            this.total= hari*42000;
        }
        else if (pilihan == 3) {
            this.total=  hari*31000;
        }
        else if (pilihan == 4) {
            this.total= hari*26000;
        }
        else {
            throw new ArithmeticException("Pilihan hanya 1 - 4 !!!");
        }
    }

    @Override
    public void getUang(int uangg) {
        this.uangg = uangg;
    }

    @Override
    public void kembaliann() {
        System.out.println("Kembalian anda : "+ (this.uangg - this.total));   }
}

