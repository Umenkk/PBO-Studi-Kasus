import java.util.Scanner;

public class pembayaran extends Sewa implements bayar {
    @Override
    public void bayarr(int uang) {

        System.out.println("Uang pembayaran anda : " + uang);
        }


    }

