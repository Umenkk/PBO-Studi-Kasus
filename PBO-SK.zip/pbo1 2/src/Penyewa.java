import java.lang.ref.SoftReference;
import java.util.Scanner;

public class Penyewa  {
    private int id_penyewa;
    private String nama_penyewa;
    private int telp;
    private String alamat;

    public void setId_penyewa(int id_penyewa){
        this.id_penyewa = id_penyewa;
    }

    public void setNama_penyewa(String nama_penyewa){
        this.nama_penyewa = nama_penyewa;
    }

    public void setTelp(int telp){
        this.telp = telp;
    }

    public void setAlamat(String alamat){
        this.alamat = alamat;
    }

    public void nama_penyewa(String nama_penyewa){
        System.out.println("+---------------------------+");
        System.out.printf("Nama Penyewa :  " + nama_penyewa);
        System.out.println();
    }

    public void notelp_penyewa(int telp){
        System.out.printf("Nomor Telpon Penyewa : " + telp);
        System.out.println();
    }

    public void Alamat(String alamat){
        System.out.printf("Alamat Penyewa : " + alamat);
        System.out.println();
        System.out.println("+---------------------------+");
    }

}
