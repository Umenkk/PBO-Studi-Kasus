public interface bayar {
     public int uang=0;

    public void bayarr(int uang);
}
