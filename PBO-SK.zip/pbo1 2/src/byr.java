abstract class byr {

    public int total;

    public int biaya_sewa;
    public int hari;
    public long harga;
    public int kembalian;
    public int uangg;

    public void getTotal(int harga, int hari){
        this.total = harga * hari;
    }

    public void getUang(int uangg){
        this.uangg = uangg;
    }

    public void kembaliann(){
        System.out.println("Kembalian anda : " + (this.uangg - this.total));
    }

}
