import java.util.Scanner;

public class Pancingan {
    private int id_pancingan;
    private String jenis_pancingan;
    private int harga;

    public void setId_pancingan(int id_pancingan){
        this.id_pancingan = id_pancingan;
    }

    public void setJenis_pancingan(String jenis_pancingan){
        this.jenis_pancingan= jenis_pancingan;
    }

    public void setHarga(int harga){
        this.harga = harga;
    }

    public void id_pancing(int id_pancingan){
        System.out.printf("ID Pancingan : " + id_pancingan);
        System.out.println();
    }

    public void jenis_pancing(String jenis_pancingan){
        System.out.printf("Jenis Pancingan : " + jenis_pancingan);
        System.out.println("");
    }

    public void Harga(int harga){
        System.out.printf("Harga Pancingan : " + harga);
        System.out.println();
        System.out.println("+---------------------------+");
        System.out.println();
    }

}
