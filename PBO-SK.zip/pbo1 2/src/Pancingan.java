import java.util.Scanner;

public class Pancingan {

    int pilihan;
    private int id_pancingan;
    public  String jenis_pancingan;
    public int harga;

    public void setId_pancingan(int id_pancingan){
        this.id_pancingan = id_pancingan;
    }

    public void setJenis_pancingan(int pilihan){
        if(pilihan == 1){
            this.jenis_pancingan= "Joran Spinning";
        }
        else if (pilihan == 2) {
            this.jenis_pancingan= "Joran Baitcasting";
        }
        else if (pilihan == 3) {
            this.jenis_pancingan= "Joran Popping";
        }
        else if (pilihan == 4) {
            this.jenis_pancingan= "Joran Trolling";
        }
        else {
            throw new ArithmeticException("Pilihan hanya 1 - 4 !!!");
        }
    }

    public void setHarga(int pilihan){
        if(pilihan == 1){
            this.harga= 20000;
        }
        else if (pilihan == 2) {
            this.harga= 42000;
        }
        else if (pilihan == 3) {
            this.harga= 31000;
        }
        else if (pilihan == 4) {
            this.harga= 26000;
        }
        else {
            throw new ArithmeticException("Pilihan hanya 1 - 4 !!!");
        }
    }

    public void id_pancing(int id_pancingan){
        System.out.printf("ID Pancingan : " + id_pancingan);
        System.out.println();
    }

    public void listPancingan(){
        System.out.println("+--------------------------+-----------------+");
        System.out.println("|      LIST PANCINGAN      |     HARGA       |");
        System.out.println("| 1. Joran Spinning        |   Rp.20,000.    |");
        System.out.println("| 2. Joran Baitcasting     |   Rp.42,000.    |");
        System.out.println("| 3. Joran Popping         |   Rp.31,000.    |");
        System.out.println("| 4. Joran Trolling        |   Rp.26,000.    |");
        System.out.println("+--------------------------+-----------------+");
        System.out.println();
    }

    public void pancing(int pilihan){
        if(pilihan == 1){
            System.out.println("Jenis Pancingan = " + this.jenis_pancingan);
            System.out.println("Harga           = " + this.harga);
        }
        else if (pilihan == 2) {

            harga = 42000;
            System.out.println("Jenis Pancingan = " + jenis_pancingan);
            System.out.println("Harga           = " + this.harga);
        }
        else if (pilihan == 3) {

            harga = 31000;
            System.out.println("Jenis Pancingan = " + jenis_pancingan);
            System.out.println("Harga           = " + this.harga);
        }
        else if (pilihan == 4) {
            jenis_pancingan = "Joran Trolling";
            harga = 26000;
            System.out.println("Jenis Pancingan = " + jenis_pancingan);
            System.out.println("Harga           = " + this.harga);
        }
        else {
            throw new ArithmeticException("Pilihan hanya 1 - 4 !!!");
        }
    }

    public void jenis_pancing(String jenis_pancingan){
        System.out.printf("Jenis Pancingan : " + jenis_pancingan);
        System.out.println("");
    }

    public void Harga(int harga){
        System.out.printf("Harga Pancingan : " + harga);
        System.out.println();
        System.out.println("+---------------------------+");
        System.out.println();
    }

}
