import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

public class Struk extends kwitansiSewa {
    String nama;
    int ID;
    int noHP;
    String alamat;
    int durasi;
    int tanggal_mulai,tanggal_seleasi;
    int Uang;





    public void bayarrr(int Uang) {
        this.Uang = Uang;
    }

    @Override
    public void setHarga(int pilihan) {
        if(pilihan == 1){
            this.harga= 20000;
        }
        else if (pilihan == 2) {
            this.harga= 42000;
        }
        else if (pilihan == 3) {
            this.harga= 31000;
        }
        else if (pilihan == 4) {
            this.harga= 26000;
        }
        else {
            throw new ArithmeticException("Pilihan hanya 1 - 4 !!!");
        }
    }


    public void setJenis_pancingann(int pilihan){
        if(pilihan == 1){
            this.jenis_pancingan= "Joran Spinning";
        }
        else if (pilihan == 2) {
            this.jenis_pancingan= "Joran Baitcasting";
        }
        else if (pilihan == 3) {
            this.jenis_pancingan= "Joran Popping";
        }
        else if (pilihan == 4) {
            this.jenis_pancingan= "Joran Trolling";
        }
        else {
            throw new ArithmeticException("Pilihan hanya 1 - 4 !!!");
        }
    }

    @Override
    public void setTotal(int pilihan, int hari) {
        if(pilihan == 1){
            this.total= hari*this.harga;
        }
        else if (pilihan == 2) {
            this.total= hari*this.harga;
        }
        else if (pilihan == 3) {
            this.total=  hari*this.harga;
        }
        else if (pilihan == 4) {
            this.total= hari*this.harga;
        }
        else {
            throw new ArithmeticException("Pilihan hanya 1 - 4 !!!");
        }
    }


    public void Strukk(int ID, String nama, int noHP, String alamat, int durasi, int tanggal_mulai, int tanggal_seleasi) {
        try {
            FileWriter myWriter = new FileWriter("Struk.txt");
            myWriter.write("ID Kwitansi        : " + ID + "\n\n");

            myWriter.write("Nama Penyewa       : " + nama + "\n");

            myWriter.write("No HP Penyewa      : " + noHP + "\n");

            myWriter.write("Alamat Penyewa     : " + alamat + "\n");

            myWriter.write("Jenis Pancingan    : " + this.jenis_pancingan + "\n");

            myWriter.write("Jenis Pancingan    : " + this.harga + "\n");

            myWriter.write("Durasi Sewa /hari  : " + durasi + "\n");

            myWriter.write("Tanggal Mulai      : " + tanggal_mulai + "\n");

            myWriter.write("Tanggal Selesai    : " + tanggal_seleasi + "\n");

            myWriter.write("Total Pembayaran   : " + this.total + "\n");

            myWriter.write("Uang Pembayaran    : " + this.Uang + "\n");

            myWriter.write("Uang Kembalian     : " + (this.Uang - this.total) + "\n");
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}





