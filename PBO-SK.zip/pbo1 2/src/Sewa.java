import java.util.Scanner;

public class  Sewa extends Pancingan {
    private int biaya_sewa;
    private int tanggal_mulai;
    private int tanggal_selesai;

    private int hari;
    private int no_kwitansi;
    public long total;
    private long hargaa;

    public void setTotal(int pilhan,int hari){
    }



     @Override
    public void setJenis_pancingan(int pilihan) {

    }

    @Override
    public void setHarga(int pilihan) {
    }

    @Override
    public void Harga(int harga) {
        super.Harga(harga);
    }

    public void hari(int hari){
        System.out.println("+---------------------------+");
        System.out.println("Anda menyewa selama : " + hari);
    }

    public void tanggal(int tanggal_mulai, int tanggal_selesai){
        System.out.println("tanggal awal sewa : " +tanggal_mulai);
        System.out.println("tanggal selesai sewa : " + tanggal_selesai);
    }



    public void totall(int hari){
        System.out.println("Total biaya penyewaan anda adalah : "+ total);
        System.out.println();
        System.out.println("+---------------------------+");


    }

}
