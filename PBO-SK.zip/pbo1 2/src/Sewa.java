import java.util.Scanner;

public class  Sewa extends Pancingan {
    private int biaya_sewa;
    private int tanggal_mulai;
    private int tanggal_selesai;

    private int hari;
    private int no_kwitansi;
    private long total;
    private long hargaa;

    public void biayaPancingan_hari(int biaya_sewa){
        System.out.println("Biaya Sewa / hari : " + biaya_sewa);
    }

    public void hari(int hari){
        System.out.println("+---------------------------+");
        System.out.println("Anda menyewa selama : " + hari);
    }

    public void tanggal(int tanggal_mulai, int tanggal_selesai){
        System.out.println("tanggal awal sewa : " +tanggal_mulai);
        System.out.println("tanggal selesai sewa : " + tanggal_selesai);
    }



    public void totall(int biaya_sewa, int hari, long hargaa){
        System.out.println("Total biaya penyewaan anda adalah : "+ (biaya_sewa*hari+hargaa));
        System.out.println();
        System.out.println("+---------------------------+");

    }

}
