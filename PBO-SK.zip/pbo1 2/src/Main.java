import com.sun.source.doctree.BlockTagTree;

import java.awt.image.Kernel;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Penyewa penyewa = new Penyewa();
        Pancingan pancingan = new Pancingan();
        Sewa sewa = new Sewa();
        kwitansiSewa kwtsewa = new kwitansiSewa();
        kwitansiKembali kwtkembali = new kwitansiKembali();
        pembayaran pmbrn = new pembayaran();
        Struk strk = new Struk();

        System.out.print("Masukkan nama Penyewa : ");
        String nama = sc.nextLine();
        System.out.print("Masukkan Nomor Telpon Penyewa : ");
        int telp = sc.nextInt();
        sc.nextLine();
        System.out.print("Masukkan Alamat Penyewa : ");
        String alamat = sc.nextLine();
        System.out.println();

        pancingan.listPancingan();

        System.out.println("Masukkan Pilihan Anda : ");
        int pilihan = sc.nextInt();



        penyewa.nama_penyewa(nama);
        penyewa.notelp_penyewa(telp);
        penyewa.Alamat(alamat);

        pancingan.setJenis_pancingan(pilihan);
        pancingan.setHarga(pilihan);
        pancingan.pancing(pilihan);

        System.out.print("Masukkan ID Kwitansi : " );
        int ID_kwt = sc.nextInt();
        sc.nextLine();
        System.out.print("Berapa lama durasi penyewaan (hari) : ");
        int day = sc.nextInt();
        sc.nextLine();
        System.out.printf("Masukkan tanggal mulai : ");
        int tgl_mulai = sc.nextInt();
        System.out.printf("Masukkan tanggal selesai : ");
        int tgl_selesai = sc.nextInt();

        kwtsewa.setHarga(pilihan);
        kwtsewa.setTotal(pilihan,day);
        kwtsewa.setJenis_pancingan(pilihan);
        kwtsewa.idKwitansi(ID_kwt);
        kwtsewa.hari(day);
        kwtsewa.tanggal(tgl_mulai,tgl_selesai);
        kwtsewa.totall(day);

        System.out.println("Masukkan Uang pembayaran : ");
        int byr = sc.nextInt();

        pmbrn.setTotalll(pilihan,day);
        pmbrn.bayarr(byr);
        pmbrn.setTotalll(pilihan,day);
        pmbrn.getUang(byr);
        pmbrn.kembaliann();

        strk.setHarga(pilihan);
        strk.setJenis_pancingann(pilihan);
        strk.setTotal(pilihan, day);
        strk.bayarrr(byr);

        strk.Strukk(ID_kwt, nama, telp,alamat, day, tgl_mulai,tgl_selesai);



    }
}