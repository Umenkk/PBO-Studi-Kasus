import java.awt.image.Kernel;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Penyewa penyewa = new Penyewa();
        Pancingan pancingan = new Pancingan();
        Sewa sewa = new Sewa();
        kwitansiSewa kwtsewa = new kwitansiSewa();

        kwitansiKembali kwtkembali = new kwitansiKembali();



        penyewa.displayInfo();
        pancingan.displayInfo();


        sewa.biayaPancingan_hari(12000);
        sewa.hari(2);
        sewa.tanggal(2,4);
        sewa.totall(12000,2);

        kwtsewa.idKwitansi(2231);
        kwtsewa.hari(2);
        kwtsewa.tanggal(12,14);
        kwtsewa.totall(12000,2);

        kwtkembali.tanggal(2,4);
        kwtkembali.tanggalbalik(5);
        kwtkembali.terlambat(1);
        kwtkembali.denda(4000,2);
    }
}