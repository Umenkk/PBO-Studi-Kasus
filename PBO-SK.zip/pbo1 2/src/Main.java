import com.sun.source.doctree.BlockTagTree;

import java.awt.image.Kernel;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Penyewa penyewa = new Penyewa();
        Pancingan pancingan = new Pancingan();
        Sewa sewa = new Sewa();
        kwitansiSewa kwtsewa = new kwitansiSewa();
        kwitansiKembali kwtkembali = new kwitansiKembali();
        pembayaran pmbrn = new pembayaran();

        System.out.print("Masukkan nama Penyewa : ");
        String nama = sc.nextLine();
        System.out.print("Masukkan Nomor Telpon Penyewa : ");
        int telp = sc.nextInt();
        sc.nextLine();
        System.out.print("Masukkan Alamat Penyewa : ");
        String alamat = sc.nextLine();

        System.out.println();



        System.out.print("Masukkan ID pancingan : ");
        int id_pcg = sc.nextInt();
        sc.nextLine();
        System.out.print("Masukkan Jenis pancingan : ");
        String jns = sc.nextLine();
        System.out.print("Masukkan Harga pancingan : ");
        int hrg = sc.nextInt();

        penyewa.nama_penyewa(nama);
        penyewa.notelp_penyewa(telp);
        penyewa.Alamat(alamat);

        pancingan.id_pancing(id_pcg);
        pancingan.jenis_pancing(jns);
        pancingan.Harga(hrg);

        System.out.print("Masukkan Biaya Sewa /hari : ");
        int biaya_hari = sc.nextInt();
        sc.nextLine();
        System.out.print("Berapa lama durasi penyewaan (hari) : ");
        int day = sc.nextInt();
        sc.nextLine();
        System.out.printf("Masukkan tanggal mulai : ");
        int tgl_mulai = sc.nextInt();
        System.out.printf("Masukkan tanggal selesai : ");
        int tgl_selesai = sc.nextInt();
        System.out.print("Masukkan ID Kwitansi : " );
        int ID_kwt = sc.nextInt();



//        sewa.biayaPancingan_hari(biaya_hari);
//        sewa.hari(day);
//        sewa.tanggal(tgl_mulai,tgl_selesai);
//        sewa.totall(biaya_hari,day,hrg);

        kwtsewa.idKwitansi(ID_kwt);
        kwtsewa.hari(day);
        kwtsewa.tanggal(tgl_mulai,tgl_selesai);
        kwtsewa.totall(biaya_hari,day,hrg);

        System.out.println("Masukkan Uang pembayaran : ");
        int byr = sc.nextInt();

        pmbrn.bayarr(byr);





//        kwtkembali.tanggal(2,4);
//        kwtkembali.tanggalbalik(5);
//        kwtkembali.terlambat(1);
//        kwtkembali.denda(4000,2);
    }
}