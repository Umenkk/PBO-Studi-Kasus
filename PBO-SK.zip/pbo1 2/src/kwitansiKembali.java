import java.util.Scanner;

public class kwitansiKembali extends Sewa{
    private int tgl_kwitansi_kembali;
    private int terlambat;
    private int denda = 4000;

    @Override
    public void tanggal(int tanggal_mulai, int tanggal_selesai) {
        System.out.println("Tanggal mulai : " + tanggal_mulai);
        System.out.println("Tanggal selesai : " + tanggal_selesai);
    }

    public void tanggalbalik(int tgl_kwitansi_kembali){
        System.out.println("Tanggal Kembali " + tgl_kwitansi_kembali);
    }

    public void terlambat(int terlambat){
        System.out.println("Terlambat selama : " + terlambat);
    }

    public void denda(int denda, int terlambat){
        System.out.printf("Denda : " + denda*terlambat);
    }





}

