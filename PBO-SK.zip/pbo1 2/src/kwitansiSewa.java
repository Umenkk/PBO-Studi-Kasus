import java.util.Scanner;

public class kwitansiSewa extends Sewa {
    private int id_kwitansi;

  public void idKwitansi(int id_kwitansi){
      System.out.println("Id Kwitansi anda : "+ id_kwitansi);
  }

    @Override
    public void hari(int hari) {
        System.out.println("Lama Sewa : " + hari);
    }

    @Override
    public void tanggal(int tanggal_mulai, int tanggal_selesai) {
        System.out.println("Dari tanggal : " + tanggal_mulai);
        System.out.println("Sampai tanggal : " + tanggal_selesai);
  }

    @Override
    public void biayaPancingan_hari(int biaya_sewa) {
        System.out.printf("Biaya Sewa pancingan / hari : " + biaya_sewa);
    }

    public void totall(double biaya_sewa, double hari) {
        System.out.println("Total Pembayaran : " + biaya_sewa*hari);
        System.out.println();
    }
}

