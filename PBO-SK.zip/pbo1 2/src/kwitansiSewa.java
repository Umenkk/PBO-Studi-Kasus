import java.util.Scanner;

public class kwitansiSewa extends Sewa {
    private int id_kwitansi;

  public void idKwitansi(int id_kwitansi){
      System.out.println("+---------------------------+");
      System.out.println("Id Kwitansi anda : "+ id_kwitansi);
  }

    @Override
    public void hari(int hari) {
        System.out.println("Lama Sewa : " + hari);
    }

    @Override
    public void tanggal(int tanggal_mulai, int tanggal_selesai) {
        System.out.println("Dari tanggal : " + tanggal_mulai);
        System.out.println("Sampai tanggal : " + tanggal_selesai);
  }

    @Override
    public void biayaPancingan_hari(int biaya_sewa) {
        System.out.printf("Biaya Sewa pancingan / hari : " + biaya_sewa);
    }

    @Override
    public void totall(int biaya_sewa, int hari, long hargaa) {
        System.out.println("Total biaya : " + (biaya_sewa*hari+hargaa));
        System.out.println();
        System.out.println("+---------------------------+");
    }
}

