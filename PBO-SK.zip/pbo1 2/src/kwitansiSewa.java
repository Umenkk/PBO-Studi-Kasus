import java.util.Scanner;

public class kwitansiSewa extends Sewa {
    private int id_kwitansi;

    @Override
    public void setTotal(int pilihan, int hari) {
        if(pilihan == 1){
            this.total= hari*this.harga;
        }
        else if (pilihan == 2) {
            this.total= hari*this.harga;
        }
        else if (pilihan == 3) {
            this.total=  hari*this.harga;
        }
        else if (pilihan == 4) {
            this.total= hari*this.harga;
        }
        else {
            throw new ArithmeticException("Pilihan hanya 1 - 4 !!!");
        }
    }

    public void idKwitansi(int id_kwitansi){
      System.out.println("+---------------------------+");
      System.out.println("Id Kwitansi anda : "+ id_kwitansi);
  }

    @Override
    public void hari(int hari) {
        System.out.println("Lama Sewa : " + hari);
    }

    @Override
    public void tanggal(int tanggal_mulai, int tanggal_selesai) {
        System.out.println("Dari tanggal : " + tanggal_mulai);
        System.out.println("Sampai tanggal : " + tanggal_selesai);
  }


    @Override
    public void totall(int hari) {
        System.out.println("Total biaya penyewaan anda adalah : " + this.total);
        System.out.println();
        System.out.println("+---------------------------+");
    }

    @Override
    public void setHarga(int pilihan) {
        if(pilihan == 1){
            this.harga= 20000;
        }
        else if (pilihan == 2) {
            this.harga= 42000;
        }
        else if (pilihan == 3) {
            this.harga= 31000;
        }
        else if (pilihan == 4) {
            this.harga= 26000;
        }
        else {
            throw new ArithmeticException("Pilihan hanya 1 - 4 !!!");
        }
    }

    @Override
    public void setJenis_pancingan(int pilihan) {
        if(pilihan == 1){
            this.jenis_pancingan= "Joran Spinning";
        }
        else if (pilihan == 2) {
            this.jenis_pancingan= "Joran Baitcasting";
        }
        else if (pilihan == 3) {
            this.jenis_pancingan= "Joran Popping";
        }
        else if (pilihan == 4) {
            this.jenis_pancingan= "Joran Trolling";
        }
        else {
            throw new ArithmeticException("Pilihan hanya 1 - 4 !!!");
        }
    }
}

