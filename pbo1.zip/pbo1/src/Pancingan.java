import java.util.Scanner;

public class Pancingan {
    private int id_pancingan;
    private String jenis_pancingan;
    private int harga;

    public void setId_pancingan(int id_pancingan){
        this.id_pancingan = id_pancingan;
    }

    public void setJenis_pancingan(String jenis_pancingan){
        this.jenis_pancingan= jenis_pancingan;
    }

    public void setHarga(int harga){
        this.harga = harga;
    }

    public void displayInfo() {
        Scanner userinput = new Scanner(System.in);
        System.out.println("Masukkan ID Pancingan: ");
        setId_pancingan(userinput.nextInt());
        System.out.println("Masukkan Jenis Pancingan: ");
        setJenis_pancingan(userinput.next());
        System.out.println("Masukkan Harga: ");
        setHarga(userinput.nextInt());
        System.out.println("ID Pancingan " + this.id_pancingan);
        System.out.println("Jenis Pancingan " + this.jenis_pancingan);
        System.out.println("Harga " + this.harga);
    }
}
