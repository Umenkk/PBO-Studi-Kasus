import java.util.Scanner;

public class kwitansiKembali {
    private int no_kwitansi_kembali;
    private int tgl_kwitansi_kembali;
    public void setNo_kwitansi_kembali(int no_kwitansi_kembali){
        this.no_kwitansi_kembali = no_kwitansi_kembali;
    }

    public void setTgl_kwitansi_kembali(int tgl_kwitansi_kembali){
        this.tgl_kwitansi_kembali = tgl_kwitansi_kembali;
    }

    public int getNo_kwitansi_kembali(){
        return no_kwitansi_kembali;
    }



    public void displayInfo() {
        Scanner userinput = new Scanner(System.in);
        System.out.println("Masukkan No Kwitansi Kembali: ");
        setNo_kwitansi_kembali(userinput.nextInt());
        System.out.println("Masukkan tanggal Kwitansi Kembali: ");
        setTgl_kwitansi_kembali(userinput.nextInt());
        System.out.println("No Kwitansi Kembali " + this.no_kwitansi_kembali);
        System.out.println("Tgl Kwitansi Kembali " + this.tgl_kwitansi_kembali);
    }



}

