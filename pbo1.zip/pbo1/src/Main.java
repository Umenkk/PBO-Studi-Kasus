import java.awt.image.Kernel;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Penyewa penyewa = new Penyewa();
        Pancingan pancingan = new Pancingan();
        Sewa sewa = new Sewa();
        kwitansiSewa kwtsewa = new kwitansiSewa();
        kembali balik = new kembali();
        kwitansiKembali kwtkembali = new kwitansiKembali();



        penyewa.displayInfo();
        pancingan.displayInfo();
        sewa.displayInfo();
        kwtsewa.displayInfo();
        balik.displayInfo();
        kwtkembali.displayInfo();
    }
}