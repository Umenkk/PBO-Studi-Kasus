import java.util.Scanner;

public class kwitansiSewa {
    private int no_kwitansi;
    private int tgl_sewa;
    private int total;

    public void setNo_kwitansi(int no_kwitansi){
        this.no_kwitansi = no_kwitansi;
    }

    public void setTgl_sewa(int tgl_sewa){
        this.tgl_sewa = tgl_sewa;
    }

    public void setTotal(int total){
        this.total = total;
    }

    public int getNo_kwitansi(){
        return no_kwitansi;
    }

    public int getTgl_sewa(){
        return tgl_sewa;
    }

    public int getTotal(){
        return total;
    }

    public void displayInfo() {
        Scanner userinput = new Scanner(System.in);
        System.out.println("Masukkan No Kwitansi : ");
        setNo_kwitansi(userinput.nextInt());
        System.out.println("Masukkan tanggal Sewa: ");
        setTgl_sewa(userinput.nextInt());
        System.out.println("Masukkan Total: ");
        setTgl_sewa(userinput.nextInt());
        System.out.println("No Kwitansi Kembali " + this.no_kwitansi);
        System.out.println("Tgl Kwitansi Kembali " + this.tgl_sewa);
        System.out.println("Tgl Kwitansi Kembali " + this.total);
    }
}
